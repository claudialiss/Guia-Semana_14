package com.uped.ejemplos.modelo;

import com.uped.ejemplos.modelo.Espera;
import com.uped.ejemplos.modelo.Espera2;
import com.uped.ejemplos.modelo.Hotel;
import com.uped.ejemplos.modelo.Jerarquia;
import com.uped.ejemplos.modelo.Multi;
import com.uped.ejemplos.modelo.Nunca;
import com.uped.ejemplos.modelo.Nunca2;
import com.uped.ejemplos.modelo.Orden;
import com.uped.ejemplos.modelo.Orden2;
import com.uped.ejemplos.modelo.Recursion;
import com.uped.ejemplos.modelo.Reservas;

public class Main {

    static void probar(String dato) {
        try {
            int noches = Integer.parseInt(dato);
            System.out.println("Precio por noche: " + (300 / noches));
        } catch (ArithmeticException e) {
            System.out.println("Aritmetica: " + e.getMessage());
        } catch (RuntimeException e) {
            System.out.println("Otra en ejecucion: "
                    + e.getClass().getSimpleName());
        } catch (Exception e) {
            System.out.println("General");
        }
    }

    public static void main(String[] args) {

        // Nunca2
        System.out.println("Hola");

        // Orden: 4 / 0 lanza ArithmeticException
        try {
            int noches = 4 / 0;
        } catch (ArithmeticException e) {
            System.out.println("Aritmetica");
        } catch (Exception e) {
            System.out.println("General");
        }

        // Orden2
        probar("3");
        probar("0");
        probar("tres");

        // Multi
        String[] noches = {"2", "x", null};
        for (String n : noches) {
            try {
                System.out.println("Noches: "
                        + Integer.parseInt(n.trim()));
            } catch (NumberFormatException | NullPointerException e) {
                System.out.println("Dato invalido: "
                        + e.getClass().getSimpleName());
            }
        }

        // Reservas no imprime nada porque su clase está vacía.
    }
}