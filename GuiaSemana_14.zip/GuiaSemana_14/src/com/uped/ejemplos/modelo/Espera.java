package com.uped.ejemplos.modelo;

public class Espera {
    public static void main(String[] args) {
        System.out.println("Procesando reserva...");

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            System.out.println("El proceso fue interrumpido");
            Thread.currentThread().interrupt();
            return;
        }

        System.out.println("Listo");
    }
}