package com.uped.ejemplos.modelo;

public class Nunca {
    public static void main(String[] args) {
        System.out.println("Hola");
    }
}