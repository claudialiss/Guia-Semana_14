package com.uped.ejemplos.modelo;

public class Orden {
    public static void main(String[] args) {
        try {
            int noches = 4 / 0;
        } catch (ArithmeticException e) {
            System.out.println("Aritmetica");
        } catch (Exception e) {
            System.out.println("General");
        }
    }
}